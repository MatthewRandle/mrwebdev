const sgMail = require("@sendgrid/mail");

exports.handler = async () => {
    return sgMail;
};